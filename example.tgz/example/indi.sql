BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS families (
    family_id INTEGER PRIMARY KEY AUTOINCREMENT,
    family_group TEXT,
    family_name TEXT
);

CREATE TABLE IF NOT EXISTS people (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    family_group TEXT,
    family_name TEXT,
    family_id INTEGER
);

INSERT INTO families (family_id, family_group, family_name) VALUES (1, 'Doe Family', 'John & Jane Doe');

INSERT INTO people (id, name, family_group, family_name, family_id) VALUES (1, 'John Doe', 'Doe Family', 'John & Jane Doe', 1);
INSERT INTO people (id, name, family_group, family_name, family_id) VALUES (2, 'Jane Smith', 'Doe Family', 'John & Jane Doe', 1);
INSERT INTO people (id, name, family_group, family_name, family_id) VALUES (3, 'Robert Doe', 'Doe Family', 'John & Jane Doe', 1);

COMMIT;
